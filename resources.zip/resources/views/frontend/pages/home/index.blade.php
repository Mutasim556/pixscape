@extends('frontend.pages.shared.app')
@php
    $logo = \App\Models\Admin\Logo::first();
@endphp
@push('css')
    <style>
        .section_bottom.is-about {
            display: flex;
            flex-wrap: wrap;
            /* 👈 REQUIRED */
            gap: 1.5rem;
        }

        .about_card {
            flex: 0 0 100%;
        }

        @media (min-width: 992px) {
            .about_card {
                flex: 0 0 calc(33.3333% - 1.5rem);
            }
        }
    </style>
@endpush
@php
    $content = \App\Models\Admin\Content::first();
@endphp
@section('content')
    <main class="page-main">
        <section class="section">
            <div class="w-layout-blockcontainer container w-container">
                <div data-light-nav="" no-gradient="" class="home-hero_wrap">
                    <div class="page-padding is-loader">
                        <div class="home-hero_logo-wrap">
                            <div class="home-hero-logo">
                                <div class="preloader_logo-a w-embed">
                                    <img src="{{ asset($logo ? $logo->main_site_header_logo : '') }}" alt="Logo"
                                        style="width: auto; height: 100%;" />
                                </div>
                                <div class="home-hero_logo-mid">
                                </div>
                                <div class="preloader_logo-dot w-embed">

                                </div>
                            </div>
                        </div>
                    </div><a data-lenis-toggle="" href="#" class="nav_link scroll">Projects</a>
                </div>
            </div>
            <div class="home-hero_featured-project_component w-dyn-list">
                <div role="list" class="w-dyn-items">
                    @php
                        $slider = App\Models\Admin\HomepageSilder::where([['status', 1], ['delete', 0]])
                            ->inRandomOrder()
                            ->first();
                    @endphp
                    <div role="listitem" class="home-hero_featured-project_item w-dyn-item">
                        <div class="img_overflow is-full"><img alt=""
                                src="{{ asset('public/' . $slider->slider_image) }}" sizes="100vw" class="full-img" />
                        </div>
                        <div class="home-hero_indicators page-padding">
                            <div class="hero_text" style="color:white">Scroll Down</div>
                            <div class="hero_text is-mobile-centered w-embed"><a href="/project/halcyon-blu"
                                    style="color:white">{{ $slider->slider_title }}</a></div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        @php
            $video = \App\Models\Admin\HomepageVideo::first();
        @endphp
        <section class="section is-dark-tan">
            <div class="w-layout-blockcontainer container w-container">
                <div class="page-padding">
                    <div class="intro_wrap">
                        <div class="intro_sticky">
                            <div scrub-each-word="" text-split="" class="intro_paragraph">
                                {{-- <h1 class="intro_text">Archipelago is a distinguished Australian city-making
                                        practice. </h1> --}}
                                <p class="intro_text">{{ $video ? $video->description : '' }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="reveal_section">
            <div class="reveal_sticky">
                <div class="reveal_path"><img src="{{ asset('public/back2.svg') }}" loading="lazy" alt=""
                        class="reveal_logo-img" /></div>
                <div class="reveal_wrap">
                    <div class="reveal_logomark-wrap">
                        <img src="{{ asset($logo ? $logo->main_site_header_logo : '') }}" loading="lazy" alt=""
                            class="reveal_logomark" />
                    </div>
                </div>
                <div class="reveal_embed-wrap">
                    <div class="reveal_embed-contain">
                        <div class="reveal_embed w-embed w-iframe">
                            <div style="padding:56.25% 0 0 0;position:relative;">
                                <iframe
                                    src="https://player.vimeo.com/video/{{ $video ? $video->video_link : '' }}?background=1"
                                    loading="lazy" style="position:absolute;top:0;left:0;width:100%;height:100%;"
                                    frameborder="0" allow="autoplay; fullscreen" allowfullscreen>
                                </iframe>
                                {{--
                               <iframe src="https://player.vimeo.com/video/1154338273?badge=0&amp;autopause=0&amp;player_id=0&amp;app_id=58479" width="1920" height="1080" frameborder="0" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share" referrerpolicy="strict-origin-when-cross-origin" title="WhatsApp Video 2026-01-14 at 7.39.54 PM"></iframe> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @php
            $expertise = \App\Models\Admin\DesignExpertise::first();
        @endphp
        <section class="section is-dark-tan">
            <div class="w-layout-blockcontainer container w-container">
                <div class="page-padding">
                    <div class="section-padding is-5em">
                        <div class="section_top is-5em">
                            <div class="section_heading-wrap">
                                <h2 class="h1">Our Expertise</h2>
                            </div>
                            <div class="section_content-grid">
                                <div class="section_info-wrap">
                                    <p>{{ $expertise ? $expertise->short_description : '' }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="section_middle">
                            <div class="about_content"><img src="{{ $expertise ? $expertise->image : '' }}" loading="lazy"
                                    alt="" class="about_diagram" /></div>
                            <div class="about_content is-left-padding">
                                <p class="h5">{{ $expertise ? $expertise->title : '' }}</p>
                                <a href="{{ route('frontend.services') }}?type=Our Expertise"
                                    class="button w-inline-block">
                                    <div class="button_label">{{ $expertise ? $expertise->button_text : '' }}</div>
                                    <div class="button_arrow w-embed"><svg width="100%" style="" viewBox="0 0 23 17"
                                            fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M23.0001 8.22269L14.7774 0L14.0703 0.707107L21.1005 7.7373H0.28125V8.7373H21.0713L14.0703 15.7383L14.7774 16.4454L23.0001 8.22269Z"
                                                fill="currentColor" />
                                        </svg></div>
                                </a>
                            </div>
                        </div>
                        <div class="section_bottom is-about">
                            @php
                                $projectTypes = \App\Models\Admin\ProjectType::where([
                                    ['status', 1],
                                    ['delete', 0],
                                ])->get();
                            @endphp
                            @foreach ($projectTypes as $projectType)
                                <a data-animate="" href="{{ route('frontend.project') }}?typeid={{ $projectType->id }}"
                                    class="about_card w-inline-block">
                                    <div class="img_overflow"><img src="{{ $projectType->image }}" loading="lazy"
                                            alt="" class="about_img" />
                                        <div class="about_card-label" style="color:white">{{ $projectType->title }}</div>
                                    </div>
                                    <p>{{ $projectType->short_description }}</p>
                                </a>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section data-light-nav="" class="section is-olive">
            <div class="w-layout-blockcontainer container w-container">
                <div class="page-padding">
                    <div class="section-padding is-5em">
                        <div class="section_top ">
                            <h2 class="h1">{{ $content->home_counter_title }}</h2>
                        </div>
                        <div class="section_middle">
                            <div class="section_content-grid">
                                <div class="section_info-wrap">
                                    <p>{{ $content->home_counter_short_details }}</p>
                                    <a href="{{ route('frontend.aboutUs') }}" class="button is-light w-inline-block">
                                        <div class="button_label">{{ $content->home_counter_btn_text }}</div>
                                        <div class="button_arrow w-embed"><svg width="100%" style=""
                                                viewBox="0 0 23 17" fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M23.0001 8.22269L14.7774 0L14.0703 0.707107L21.1005 7.7373H0.28125V8.7373H21.0713L14.0703 15.7383L14.7774 16.4454L23.0001 8.22269Z"
                                                    fill="currentColor" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="section_bottom">
                            <div class="section_bottom is-call-out">
                                @php
                                    $counters = \App\Models\Admin\Counter::where([['delete', 0], ['status', 1]])->get();
                                @endphp
                                @foreach ($counters as $counter)
                                    <div id="w-node-_4b76f278-a6fe-147c-4a15-adc1cf470d1b-f9585fa4" class="call-out_wrap">
                                        <div id="w-node-_7a6add67-4f18-df75-9166-3e37a2566f49-f9585fa4"
                                            class="h-xl is-call-out"><span
                                                class="counter">{{ $counter->counter }}</span>+</div>
                                        <p id="w-node-_87801875-707b-373d-8432-4101b570e374-f9585fa4" class="call-out_p">
                                            {{ $counter->title }}
                                        </p>
                                        <div id="w-node-ad91baad-964f-256b-aa05-c068d794fc67-f9585fa4"
                                            class="call-out_illustration-contain"><img src="{{ $counter->image }}"
                                                loading="lazy" alt=""
                                                class="call-out_illustration is-workshops" /></div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section">
            <div class="w-layout-blockcontainer container w-container">
                <div class="page-padding">
                    <div class="section-padding is-5em">
                        <div class="section_top is-5em">
                            <div class="section_heading-wrap">
                                <h2 class="h1">{{ $content->home_work_title }}</h2>
                            </div>
                            <div class="section_content-grid">
                                <div class="section_info-wrap">
                                    <p>{{ $content->home_work_short_details }}</p>
                                    <a href="{{ route('frontend.project') }}" class="button w-inline-block">
                                        <div class="button_label">{{ $content->home_work_btn_text }}</div>
                                        <div class="button_arrow w-embed"><svg width="100%" style=""
                                                viewBox="0 0 23 17" fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M23.0001 8.22269L14.7774 0L14.0703 0.707107L21.1005 7.7373H0.28125V8.7373H21.0713L14.0703 15.7383L14.7774 16.4454L23.0001 8.22269Z"
                                                    fill="currentColor" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="projects-list_component">
                            <div class="projects-list_grid-wrapper w-dyn-list">
                                <div role="list" class="projects-list_grid w-dyn-items">
                                    @php
                                        $projects = \App\Models\Admin\Project::where([['delete', 0], ['status', 1]])
                                            ->inRandomOrder()
                                            ->limit(5)
                                            ->get();
                                    @endphp
                                    @foreach ($projects as $project)
                                        <div role="listitem" class="projects-list_item w-dyn-item">
                                            <a data-animate=""
                                                href="{{ route('frontend.projectSingle', \Illuminate\Support\Str::slug($project->title)) }}?projectid={{ $project->id }}"
                                                class="vertical_0-5em w-inline-block">
                                                @php
                                                    $pimages = json_decode($project->images);
                                                @endphp
                                                <div class="img_overflow"><img src="{{ $pimages[0] }}" loading="lazy"
                                                        alt=""
                                                        sizes="(max-width: 767px) 100vw, (max-width: 991px) 728px, 940px"
                                                        srcset="{{ $pimages[0] }}" class="img" />
                                                    <div class="link-reveal_component">
                                                        <div class="link-reveal_fill-wrapper">
                                                            <div class="link-reveal_fill"></div>
                                                            <div class="link-reveal_marquee">
                                                                <div class="link-reveal_track">
                                                                    <p class="track-text h-l">{{ $project->title }}
                                                                    </p>
                                                                    <p class="track-text h-l">{{ $project->title }}
                                                                    </p>
                                                                    <p class="track-text h-l">
                                                                        {{ $project->title }}
                                                                    </p>
                                                                    <p class="track-text h-l">
                                                                        {{ $project->title }}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <p>{{ $project->title }}</p>
                                            </a>
                                        </div>
                                    @endforeach

                                </div>
                            </div>
                            <div>
                                <div data-wf--block-button-group--position="center" class="button_group">
                                    <div class="display-contents">
                                        <div class="spacer-2"></div>
                                        <a href="{{ route('frontend.project') }}" class="button w-inline-block">
                                            <div class="button_label">{{ $content->home_work_btn_text }}</div>
                                            <div class="button_arrow w-embed"><svg width="100%" style=""
                                                    viewBox="0 0 23 17" fill="currentColor"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M23.0001 8.22269L14.7774 0L14.0703 0.707107L21.1005 7.7373H0.28125V8.7373H21.0713L14.0703 15.7383L14.7774 16.4454L23.0001 8.22269Z"
                                                        fill="currentColor" />
                                                </svg></div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section data-cms-marquee-section="" data-light-nav="" class="section is-olive">
            <div class="w-layout-blockcontainer container w-container">
                <div class="section-padding is-6-5em">
                    <div class="page-padding">
                        <h3 class="projects_sub-heading">{{ $content->home_work_current_text }}</h3>
                    </div>
                    @php
                        $projects = \App\Models\Admin\Project::where([['delete', 0], ['status', 1]])
                            ->inRandomOrder()
                            ->limit(10)
                            ->get();
                    @endphp
                    <div class="cms-marquee_component">
                        <div class="cms-marquee_row-wrapper is-no-hover-pause">
                            <div class="cms-marquee_row">
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                        @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cms-marquee_row-wrapper is-inverse is-no-hover-pause">
                            <div class="cms-marquee_row">
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cms-marquee_row-wrapper is-no-hover-pause">
                            <div class="cms-marquee_row">
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cms-marquee_row-wrapper is-inverse is-no-hover-pause">
                            <div class="cms-marquee_row">
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cms-marquee_row-wrapper is-no-hover-pause">
                            <div class="cms-marquee_row">
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="w-dyn-list">
                                    <div role="list" class="cms-marquee_list w-dyn-items">
                                         @foreach ($projects as $project)
                                        <div role="listitem" class="cms-marquee_item w-dyn-item">
                                            <a href="#" class="cms-marquee_link w-inline-block">
                                                <div data-dot-color="light-tan" class="dot"></div>
                                                <div class="cms-marquee_text h-xl">{{ $project->title }}
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        @php
            $teaminfo = \App\Models\Admin\TeamInfo::first();
        @endphp
        <section class="section">
            <div class="w-layout-blockcontainer container w-container">
                <div class="page-padding">
                    <div class="section-padding is-5em">
                        <div class="section_top is-5em">
                            <div class="section_heading-wrap">
                                <h2 class="h1">Team</h2>
                            </div>
                            <div class="section_content-grid">
                                <div class="section_info-wrap">
                                    <p>{{ $teaminfo ? $teaminfo->short_description : '' }}</p>
                                    <a href="{{ route('frontend.team') }}" class="button w-inline-block">
                                        <div class="button_label">{{ $teaminfo ? $teaminfo->button_text : '' }}</div>
                                        <div class="button_arrow w-embed"><svg width="100%" style=""
                                                viewBox="0 0 23 17" fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M23.0001 8.22269L14.7774 0L14.0703 0.707107L21.1005 7.7373H0.28125V8.7373H21.0713L14.0703 15.7383L14.7774 16.4454L23.0001 8.22269Z"
                                                    fill="currentColor" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="section_bottom">
                            <div class="vertical_0-5em"><img src="{{ $teaminfo ? $teaminfo->team_image : '' }}"
                                    loading="lazy"
                                    sizes="(max-width: 767px) 100vw, (max-width: 991px) 727.989990234375px, 939.989990234375px"
                                    alt="" class="img_wide" />
                                <p>The Pixscape Team</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section data-light-nav="" class="section">
            <div class="w-layout-blockcontainer container w-container">
                <div class="cta_wrap">
                    <div class="cta_marquee">
                        <a href="{{ route('frontend.contact') }}" class="cta_marquee-content w-inline-block">
                            <div class="cta_marquee-text h-xl">{{ $content->home_work_contact_text }}</div>
                            <div class="dot is-light"></div>
                            <div aria-hidden="true" class="cta_marquee-text h-xl">{{ $content->home_work_contact_text }}</div>
                            <div class="dot is-light"></div>
                            <div aria-hidden="true" class="cta_marquee-text h-xl">{{ $content->home_work_contact_text }}</div>
                            <div class="dot is-light"></div>
                            <div aria-hidden="true" class="cta_marquee-text h-xl">{{ $content->home_work_contact_text }}</div>
                            <div class="dot is-light"></div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="img_overflow is-cta"><img
                    src="{{ asset($content->home_work_contact_image) }}"
                    loading="lazy" sizes="(max-width: 1920px) 100vw, 1920px"
                    srcset="{{ asset($content->home_work_contact_image) }}"
                    alt="#" class="cta_img" />
            </div>
        </section>
    </main>
@endsection
